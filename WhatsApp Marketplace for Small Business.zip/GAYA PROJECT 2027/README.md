# GAYA PROJECT 2027 — Developer Handoff / Pakè pou ekip devlopman

> **EN** — This folder contains every design for Gaya Maket: a WhatsApp-first marketplace + POS + delivery platform for small businesses in Haiti and the diaspora. Open `00 Konpilasyon - START HERE.dc.html` in a browser first.
>
> **KR** — Dosye sa a gen tout konsepsyon Gaya Maket yo: yon mache sou WhatsApp + kès POS + livrezon pou ti biznis ann Ayiti ak nan dyaspora a. Louvri `00 Konpilasyon - START HERE.dc.html` nan yon navigatè an premye.

---

## 1. About these files / Sou fichye sa yo

**EN.** These are **high-fidelity design references built in HTML**. They are working prototypes that show the intended look, copy and behavior. They are **not production code**. Rebuild them in the chosen stack (recommended: React Native + Expo for the two store apps, Next.js for the customer web storefront, Supabase or Firebase for real-time data), matching colors, type, spacing and flows exactly. All data, payments, GPS and verification in the prototypes are **simulated**.

**KR.** Se **referans konsepsyon wo fidelite ki fèt an HTML**. Yo montre aparans, tèks ak kijan chak bagay dwe mache. Yo **pa kòd pwodiksyon**. Rekonstwi yo nan teknoloji ou chwazi a (rekòmande: React Native + Expo pou 2 app yo, Next.js pou boutik web kliyan an, Supabase oswa Firebase pou done an dirèk). Done, peman, GPS ak verifikasyon nan prototip yo se **simulasyon**.

**How to open / Kijan pou louvri:** serve the folder with any static server (e.g. `npx serve .`) and open the `.dc.html` files. Each file is self-contained HTML; `support.js` is the runtime.

---

## 2. Products to build / Pwodwi pou konstwi

| # | Product | Platform | Users |
|---|---|---|---|
| 1 | **Gaya Biznis** | iOS + Android app | Merchants / Machann |
| 2 | **Gaya Chofè** | iOS + Android app | Drivers / Chofè |
| 3 | **Gaya Boutik** (customer storefront) | Web, opens from WhatsApp link `gayamaket.com/<store>` | Customers / Kliyan (no download) |
| 4 | **Gaya Maket** marketing site | Web | Public |
| 5 | Admin (KYC review, fraud, payouts) | Web | Gaya team |

---

## 3. Files / Fichye yo

| File | What it is (EN) | Sa li ye (KR) |
|---|---|---|
| `00 Konpilasyon - START HERE.dc.html` | Every page at desktop (1440) and mobile (390), with per-page fix list and competitor comparison | Tout paj yo an desktop ak mobil, lis pou ranje, konparezon |
| `Gaya Maket Landing.dc.html` | Marketing landing page, fully responsive | Landing page, adapte pou mobil |
| `Gaya Tout An Yon.dc.html` | Live end-to-end flow: customer orders & pays → merchant accepts → driver offer (15 s countdown) → live route → delivered. Merchant dashboard below | Flux an dirèk kliyan → machann → chofè + tablodbò |
| `Gaya Konfyans.dc.html` | Payment-proof screenshot in chat with auto-verification, live customer GPS for driver, merchant KYC (name, last name, email, phone, address, ID front/back, selfie), inventory, fraud center, reviews, auto-SEO | Prèv peman nan chat, GPS kliyan, KYC, stòk, fwod, avi, SEO |
| `Gaya Biznis POS.dc.html` | Merchant POS: quick items/keypad, tap-to-pay, MonCash/NatCash QR, WhatsApp payment link, cash with change, credit tab; orders; listings (product / animal / land / house); reports. 5 languages, offline mode | Kès POS, kòmand, anons bèt/tè/kay, rapò, 5 lang |
| `Gaya Maket Ad.dc.html` | 9:16 video ad (Kreyòl + Spanish), 8 service variants via Tweaks, exportable to MP4 | Videyo piblisite 9:16 |
| `Gaya Plan Lansman.dc.html` | Launch readiness review, must-fix list, stack, 6-month plan, App Store / Google Play steps | Plan lansman ak etap magazen yo |
| `Deck.dc.html` | 14-slide merchant pitch deck | Prezantasyon 14 paj |
| `gaya-i18n.js` | **All POS UI strings in ht / en / es / fr / pt** — reuse as the translation source | Tout tèks POS yo nan 5 lang |
| `gaya-ad.jsx`, `animations-v3.jsx`, `tweaks-panel.jsx` | Video ad source + animation engine | Kòd videyo a |
| `support.js`, `image-slot.js`, `deck-stage.js`, `ds-base.js`, `_ds/…` | Prototype runtime, photo slots, deck shell, base stylesheet (fonts) | Fichye teknik prototip la |

---

## 4. Design tokens / Koulè ak tipografi

**Colors**

| Token | Hex | Use |
|---|---|---|
| ink | `#0B0B0B` | Primary text, dark surfaces, primary buttons |
| white | `#FFFFFF` | Main background, cards |
| green (vibrant) | `#00D15E` | Brand accent, CTAs on dark/light, active states, success |
| green hover | `#00B852` | Pressed/hover of green |
| emerald | `#00A651` | Large accent text on white (headings, eyebrows) |
| deep green | `#007A36` | Accent body text on white (prices, links) — AA |
| forest | `#063D22` | Headings on light backgrounds |
| mint | `#9BF0BF` | Secondary text on black |
| tint | `#DCF9E7` | Soft green fills, chips, success pills |
| surface | `#F4F8F5` / `#F1F4F2` / `#EDF3EF` | Cards, inputs, page bg |
| border | `#E3E9E5`, `#CBD3CE` | Input borders, inactive toggles |
| muted text | `#4A524D`, `#5E635F` | Secondary text |
| warning | `#FFB020` / bg `#FFE9C2` / text `#5A3B00` | Low stock, pending |
| danger | `#E5484D` / bg `#FDE2E3` | Fraud, out of stock, live dot |

**Type**: Display/headings **Caprasimo** 400; body/UI **Figtree** 500–800. Scale used: 11, 12, 13, 14, 15, 16, 18, 20–24 (card titles), 30–36 (section heads), clamp(34–56px) section H2, clamp(44–88px) hero H1. Prices and numbers use Caprasimo.

**Shape**: pills `border-radius: 999px` for buttons, inputs, chips, toggles; cards 18–36px; phone frame 52px. Shadows soft and green-tinted: `0 30px 70px rgba(6,61,34,0.18)`.

**Icons**: Lucide, stroke-width 2.75.

**Motion**: entrances 0.25–0.35s ease-out translateY(18–24px); pulses 1.4–2s for live dots; toggles 0.2s.

---

## 5. Key flows & state / Flux ak eta

**Order lifecycle (Tout An Yon):** `browse → checkout → new (paid) → prep (merchant accepted) → offer (sent to driver, 15 s timer, auto-reassign on decline/timeout) → toPickup → delivering → done (rating + tip)`. Every transition must push in real time to all three apps (WebSocket / Supabase Realtime / Firestore listeners).

**Payment proof (Konfyans):** customer uploads screenshot in chat → status `pending → verifying → confirmed | suspicious`. Real verification = match **transaction ID + amount + recipient** via MonCash / NatCash merchant API; also check duplicate ID, image edit metadata. Merchant feed updates live.

**Live location:** customer shares GPS only during an active delivery (auto-stop on delivered). Driver sees customer pin + accuracy radius + landmark text + door photo + Plus Code. Use `navigator.geolocation.watchPosition` / Expo Location; background location only in the driver app (store declarations required).

**KYC:** 4 steps — personal info (first name, last name, email, phone, business address — all required, email validated) → ID type (CIN / NIF / passport) + front/back photos → selfie with ID → automated checks → "Machann verifye" badge. Store documents encrypted, restricted access.

**Inventory:** decrement on paid order; low-stock threshold (≤10) → WhatsApp alert; auto-hide at 0 (toggle); days-of-stock = qty / daily rate; one-tap restock suggestion = 3 days of sales.

**POS payments:** tap (NFC Tap-to-Pay), QR (MonCash/NatCash), payment link via WhatsApp, cash (change calc), credit tab (customer ledger). Offline: queue sales locally, sync on reconnect.

**Listings:** Product (name, stock) · Animal (type, breed, sex, age, weight kg/lb, height cm, colors multi-select, vaccinated, price, negotiable, location, description, 3 photos) · Land/House (sale/rent, area m²/kawo — 1 kawo ≈ 12,900 m², rooms, baths, papers: title/survey/notary, water/power/road) → buyer preview, "verified papers" badge when ≥2 documents.

**SEO:** auto-generate title, meta description, keywords per store in 5 languages; product pages, sitemap, Google Business/Maps.

---

## 6. Integrations / Entegrasyon

- WhatsApp Business Platform (Cloud API) — order confirmations, receipts, alerts
- MonCash & NatCash merchant APIs — payments + verification
- Card processor supporting Haiti (and/or US entity for diaspora)
- Google Maps or Mapbox + Plus Codes
- KYC/identity verification provider
- Push notifications (FCM / APNs)

---

## 7. Placeholders to replace / Sa pou ranplase

- Prices $0 / $9 / $25 per month and "0% commission" are **proposals**.
- All store names, people, phone numbers, IDs, amounts are **sample data**.
- Photo slots are empty — use real photos of Haitian merchants, food, drivers.
- `gayamaket.com` is a placeholder domain.

---

## 8. Launch / Lansman

See `Gaya Plan Lansman.dc.html`. Summary: register the company, get a D-U-N-S number, open **organization** developer accounts (Apple $99/yr, Google Play $25 one-time — organization accounts skip Google's 12-testers/14-days rule), build MVP (≈3 months), pilot with 20 merchants + 10 drivers, then submit via TestFlight and Play closed testing.

*Prepared October 2026 · Pare oktòb 2026*
