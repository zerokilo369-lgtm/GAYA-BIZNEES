// Gaya Maket — vertical WhatsApp-status ad, Kreyòl. One template, re-skinned per service via Tweaks.
const C = { white: '#FFFFFF', ink: '#0B0B0B', green: '#00D15E', greenDeep: '#007A36', tint: '#DCF9E7', chat: '#EEF2EF', grey: '#5E635F', line: '#E3E9E5' };
const FH = "'Caprasimo', Georgia, serif";
const FB = "'Figtree', system-ui, sans-serif";
const W = 604, H = 1254; // phone screen

const BIZ = ['Restoran', 'Manje lakay', 'Kafe', 'Boulanjri', 'Makèt & bouchri', 'Salon', 'Netwayaj', 'Mòd & rad', 'Bijou', 'Famasi', 'Elektwonik', 'Otèl', 'Lokasyon', 'Vwayaj', 'Tikè & evènman', 'Edikasyon', 'Pwodwi dijital', 'Gwo machann B2B'];

const SERVICES = [
  { type: 'Restoran', store: 'Lakay Manje', slug: 'lakaymanje', itemsWord: 'plat', itemsTitle: 'Meni ou',
    items: [['Diri kole ak griyo', '750 HTG'], ['Legim ak bèf', '650 HTG'], ['Bannann peze + pikliz', '250 HTG']],
    orderWord: 'Nouvo kòmand', order: [['2 × Diri kole ak griyo', '1,500'], ['1 × Bannann peze', '250']], total: '1,750',
    detail: 'Livrezon · Delma 33', reply: 'Mèsi! L ap rive nan 30 minit.', ctaFor: 'restoran' },
  { type: 'Salon', store: 'Bèl Cheve', slug: 'belcheve', itemsWord: 'sèvis', itemsTitle: 'Sèvis ou yo',
    items: [['Très', '2,500 HTG'], ['Koupe + brushing', '1,200 HTG'], ['Manikir', '800 HTG']],
    orderWord: 'Nouvo randevou', order: [['Très', '2,500'], ['Manikir', '800']], total: '3,300',
    detail: 'Samdi 10:00 · Petyonvil', reply: 'Mèsi! Nou tann ou samdi a.', ctaFor: 'salon' },
  { type: 'Otèl', store: 'Kay Lanmè', slug: 'kaylanme', itemsWord: 'chanm', itemsTitle: 'Chanm ou yo',
    items: [['Chanm doub · 1 nwit', '6,500 HTG'], ['Swit bò lanmè · 1 nwit', '9,800 HTG'], ['Dejene pou 2', '900 HTG']],
    orderWord: 'Nouvo rezèvasyon', order: [['2 nwit · Chanm doub', '13,000'], ['Dejene pou 2', '900']], total: '13,900',
    detail: '12–14 nov · Jakmèl', reply: 'Mèsi! Chanm ou an pare.', ctaFor: 'otèl' },
  { type: 'Makèt & bouchri', store: 'Mache Ti Mari', slug: 'machetimari', itemsWord: 'pwodwi', itemsTitle: 'Pwodwi ou yo',
    items: [['Vyann kabrit · 1 liv', '650 HTG'], ['Diri · sak 5 liv', '900 HTG'], ['Lwil · 1 galon', '1,100 HTG']],
    orderWord: 'Nouvo kòmand', order: [['2 × Vyann kabrit', '1,300'], ['1 × Diri 5 liv', '900']], total: '2,200',
    detail: 'Livrezon · Kafou', reply: 'Mèsi! N ap prepare l kounye a.', ctaFor: 'makèt' },
  { type: 'Boulanjri', store: 'Pen Cho Lakay', slug: 'pencholakay', itemsWord: 'pwodwi', itemsTitle: 'Pwodwi ou yo',
    items: [['Pen ayisyen · 12', '300 HTG'], ['Gato fèt', '3,500 HTG'], ['Pate kòde', '150 HTG']],
    orderWord: 'Nouvo kòmand', order: [['1 × Gato fèt', '3,500'], ['2 × Pen ayisyen', '600']], total: '4,100',
    detail: 'Pran l · Vandredi 4:00', reply: 'Mèsi! Gato a ap pare vandredi.', ctaFor: 'boulanjri' },
  { type: 'Tikè & evènman', store: 'Kanaval Fest', slug: 'kanavalfest', itemsWord: 'tikè', itemsTitle: 'Tikè ou yo',
    items: [['Tikè jeneral', '1,500 HTG'], ['Tikè VIP', '5,000 HTG'], ['Tab pou 6', '20,000 HTG']],
    orderWord: 'Nouvo tikè', order: [['2 × Tikè VIP', '10,000'], ['1 × Tikè jeneral', '1,500']], total: '11,500',
    detail: 'Kòd QR voye sou WhatsApp', reply: 'Mèsi! Nou wè w nan fèt la.', ctaFor: 'evènman' },
  { type: 'Netwayaj', store: 'Kay Klè', slug: 'kaykle', itemsWord: 'sèvis', itemsTitle: 'Sèvis ou yo',
    items: [['Netwayaj kay · 2 chanm', '3,000 HTG'], ['Netwayaj fon', '6,500 HTG'], ['Lave tapi', '1,500 HTG']],
    orderWord: 'Nouvo randevou', order: [['Netwayaj kay · 2 chanm', '3,000'], ['Lave tapi', '1,500']], total: '4,500',
    detail: 'Madi 9:00 · Tabarre', reply: 'Mèsi! Ekip la ap la madi.', ctaFor: 'netwayaj' },
  { type: 'Mòd & rad', store: 'Style Lakay', slug: 'stylelakay', itemsWord: 'atik', itemsTitle: 'Atik ou yo',
    items: [['Wòb lete', '2,200 HTG'], ['Sandal kwi', '1,500 HTG'], ['Chemiz len', '1,800 HTG']],
    orderWord: 'Nouvo kòmand', order: [['1 × Wòb lete', '2,200'], ['1 × Sandal kwi', '1,500']], total: '3,700',
    detail: 'Livrezon · Okap', reply: 'Mèsi! Pake w ap soti jodi a.', ctaFor: 'boutik' },
];

const prog = (T, s, d, fn) => fn(Math.min(1, Math.max(0, (T - s) / d)));
const MOTION = {
  enter: (T, s, d = 0.45) => prog(T, s, d, window.Easing.easeOutCubic),
  pop: (T, s, d = 0.5) => prog(T, s, d, window.Easing.easeOutBack),
  draw: (T, s, d = 1) => prog(T, s, d, window.Easing.linear),
};
const span = (T, s, e, d = 0.35) => MOTION.enter(T, s, d) * (1 - MOTION.enter(T, e, d));
const typed = (str, T, s, d) => str.slice(0, Math.round(MOTION.draw(T, s, d) * str.length));
const abs = (x, y, w, h) => ({ position: 'absolute', left: x, top: y, width: w, height: h });

function Screen({ T, from, to, bg = C.white, children }) {
  const o = span(T, from, to);
  const x = (1 - MOTION.enter(T, from, 0.5)) * 70;
  return <div style={{ ...abs(0, 0, W, H), background: bg, opacity: o, visibility: o < 0.002 ? 'hidden' : 'visible', transform: `translateX(${x}px)`, overflow: 'hidden' }}>{children}</div>;
}

function StatusBar({ light }) {
  const col = light ? C.white : C.ink;
  return <div style={{ ...abs(0, 0, W, 50), display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 40px', boxSizing: 'border-box', color: col, font: `700 22px ${FB}`, zIndex: 5 }}>
    <span>9:41</span>
    <span style={{ display: 'flex', gap: 8, alignItems: 'center' }}><span>5G</span><span style={{ width: 40, height: 18, borderRadius: 999, border: `2px solid ${col}`, boxSizing: 'border-box', padding: 2 }}><span style={{ display: 'block', width: '75%', height: '100%', borderRadius: 999, background: col }}></span></span></span>
  </div>;
}

function Tap({ T, x, y, at }) {
  const show = span(T, at - 0.35, at + 0.25, 0.2);
  const r = MOTION.enter(T, at, 0.5);
  if (T < at - 0.4 || T > at + 0.7) return null;
  return <React.Fragment>
    <div style={{ position: 'absolute', left: x - 30, top: y - 30, width: 60, height: 60, borderRadius: 999, background: 'rgba(11,11,11,0.28)', border: '3px solid #fff', boxSizing: 'border-box', opacity: show, transform: `scale(${1 - 0.15 * MOTION.enter(T, at - 0.05, 0.1) + 0.15 * MOTION.enter(T, at + 0.05, 0.15)})`, zIndex: 50 }}></div>
    <div style={{ position: 'absolute', left: x - 40, top: y - 40, width: 80, height: 80, borderRadius: 999, border: `5px solid ${C.green}`, boxSizing: 'border-box', opacity: T >= at ? (1 - r) * 0.9 : 0, transform: `scale(${0.6 + 1.6 * r})`, zIndex: 49 }}></div>
  </React.Fragment>;
}

function Btn({ x, y, w = W - 64, label, dark, green, children }) {
  return <div style={{ ...abs(x ?? 32, y, w, 100), borderRadius: 999, background: green ? C.green : dark ? C.ink : C.white, color: dark ? C.white : C.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `700 32px ${FB}` }}>{children || label}</div>;
}

function Title({ y = 110, children, sub }) {
  return <div style={{ ...abs(32, y, W - 64, 'auto') }}>
    <div style={{ font: `400 52px/1.1 ${FH}`, color: C.ink }}>{children}</div>
    {sub && <div style={{ font: `500 26px ${FB}`, color: C.grey, marginTop: 12 }}>{sub}</div>}
  </div>;
}

function HookChat({ T, S, c }) {
  const msgs = [`Bonjou! Konbyen pou ${S.items[0][0].toLowerCase()}?`, 'Li disponib toujou?', 'Tanpri voye foto yo ankò', 'Kote pou m peye a?', 'Èske ou fè livrezon?', 'Alo?? Ou la?'];
  const n = Math.round(1 + 26 * MOTION.draw(T, 0.2, 2.8));
  const shake = T > 2.6 && T < c.Reveal ? Math.sin(T * 60) * 4 : 0;
  return <Screen T={T} from={-1} to={c.Reveal + 0.1} bg={C.chat}>
    <div style={{ ...abs(0, 0, W, 160), background: C.ink }}></div>
    <StatusBar light />
    <div style={{ ...abs(32, 64, W - 64, 80), display: 'flex', alignItems: 'center', gap: 18 }}>
      <div style={{ width: 72, height: 72, borderRadius: 999, background: C.green, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `400 34px ${FH}`, color: C.ink }}>K</div>
      <div style={{ flex: 1 }}>
        <div style={{ font: `700 30px ${FB}`, color: C.white }}>Kliyan yo</div>
        <div style={{ font: `500 22px ${FB}`, color: '#BFC6C1' }}>ap ekri...</div>
      </div>
      <div style={{ minWidth: 64, height: 52, padding: '0 14px', boxSizing: 'border-box', borderRadius: 999, background: C.green, color: C.ink, font: `800 28px ${FB}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{n}</div>
    </div>
    <div style={{ ...abs(24, 190, W - 48, H - 200), display: 'flex', flexDirection: 'column', gap: 18, transform: `translateX(${shake}px)` }}>
      {msgs.map((m, i) => {
        const p = MOTION.pop(T, 0.25 + i * 0.42, 0.4);
        return <div key={i} style={{ alignSelf: 'flex-start', maxWidth: 470, background: C.white, borderRadius: '10px 30px 30px 30px', padding: '20px 26px', font: `500 30px/1.3 ${FB}`, color: C.ink, opacity: Math.min(1, p), transform: `translateY(${(1 - p) * 24}px) scale(${0.92 + 0.08 * p})`, transformOrigin: 'left top', boxShadow: '0 2px 0 rgba(0,0,0,0.05)' }}>
          {m}<div style={{ font: `500 18px ${FB}`, color: C.grey, textAlign: 'right', marginTop: 6 }}>9:4{i}</div>
        </div>;
      })}
    </div>
  </Screen>;
}

function Brand({ T, c }) {
  const r = c.Reveal;
  const p1 = MOTION.pop(T, r + 0.15, 0.6), p2 = MOTION.pop(T, r + 0.45, 0.5), p3 = MOTION.enter(T, r + 0.8, 0.5);
  return <Screen T={T} from={r} to={c.Account + 0.1} bg={C.green}>
    <StatusBar />
    <div style={{ position: 'absolute', left: -200, top: 820, width: 900, height: 900, borderRadius: 999, background: '#00BD55', transform: `scale(${0.6 + 0.4 * MOTION.enter(T, r, 1.6)})` }}></div>
    <div style={{ ...abs(0, 0, W, H), display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 34 }}>
      <div style={{ width: 230, height: 230, borderRadius: 999, background: C.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `400 150px ${FH}`, color: C.green, transform: `scale(${p1})` }}>G</div>
      <div style={{ font: `400 84px ${FH}`, color: C.ink, opacity: Math.min(1, p2), transform: `translateY(${(1 - p2) * 30}px)` }}>Gaya Maket</div>
      <div style={{ font: `600 32px ${FB}`, color: C.ink, opacity: p3 }}>Boutik ou sou WhatsApp</div>
    </div>
  </Screen>;
}

function Signup({ T, c }) {
  const a = c.Account;
  const digits = '482916'.split('');
  const ok = MOTION.pop(T, a + 2.3, 0.4);
  return <Screen T={T} from={a} to={a + 2.6}>
    <StatusBar />
    <Title sub="Sèlman nimewo WhatsApp ou">Kreye kont ou</Title>
    <div style={{ ...abs(32, 300, W - 64, 30), font: `700 24px ${FB}`, color: C.grey }}>Nimewo telefòn</div>
    <div style={{ ...abs(32, 340, W - 64, 96), borderRadius: 999, border: `3px solid ${T > a + 0.4 ? C.ink : C.line}`, boxSizing: 'border-box', display: 'flex', alignItems: 'center', padding: '0 32px', gap: 16, font: `600 34px ${FB}`, color: C.ink }}>
      <span style={{ color: C.grey }}>+509</span><span>{typed('3712 4580', T, a + 0.5, 0.8)}</span>
    </div>
    <Btn y={470} green label="Resevwa kòd" />
    <div style={{ ...abs(32, 640, W - 64, 30), font: `700 24px ${FB}`, color: C.grey, opacity: MOTION.enter(T, a + 1.55) }}>Kòd nou voye ba ou sou WhatsApp</div>
    <div style={{ ...abs(32, 690, W - 64, 100), display: 'flex', gap: 14, opacity: MOTION.enter(T, a + 1.55) }}>
      {digits.map((d, i) => <div key={i} style={{ flex: 1, height: 100, borderRadius: 24, background: T > a + 1.7 + i * 0.09 ? C.tint : '#F3F5F4', display: 'flex', alignItems: 'center', justifyContent: 'center', font: `400 44px ${FH}`, color: C.ink }}>{T > a + 1.7 + i * 0.09 ? d : ''}</div>)}
    </div>
    <div style={{ ...abs(32, 840, W - 64, 60), display: 'flex', alignItems: 'center', gap: 14, opacity: Math.min(1, ok), transform: `scale(${0.8 + 0.2 * ok})`, transformOrigin: 'left center' }}>
      <div style={{ width: 52, height: 52, borderRadius: 999, background: C.green, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `800 30px ${FB}` }}>✓</div>
      <div style={{ font: `700 30px ${FB}`, color: C.greenDeep }}>Nimewo verifye</div>
    </div>
    <Tap T={T} x={302} y={520} at={a + 1.45} />
  </Screen>;
}

function BizType({ T, S, c }) {
  const b = c.Account + 2.5;
  const idx = Math.max(0, BIZ.indexOf(S.type));
  const pos = (i) => ({ x: 32 + (i % 2) * 278, y: 230 + Math.floor(i / 2) * 70 });
  const sel = T > b + 0.95;
  const sp = pos(idx);
  return <Screen T={T} from={b} to={c.Products}>
    <StatusBar />
    <Title>Ki kalite biznis ou?</Title>
    {BIZ.map((l, i) => {
      const p = pos(i); const on = sel && i === idx;
      return <div key={l} style={{ ...abs(p.x, p.y, 262, 58), borderRadius: 999, background: on ? C.green : '#F1F4F2', color: C.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `${on ? 800 : 600} 24px ${FB}`, opacity: MOTION.enter(T, b + 0.1 + i * 0.025, 0.3), transform: on ? `scale(${1 + 0.06 * (1 - MOTION.enter(T, b + 0.95, 0.4))})` : 'none' }}>{l}</div>;
    })}
    <div style={{ ...abs(32, 900, W - 64, 30), font: `700 24px ${FB}`, color: C.grey, opacity: MOTION.enter(T, b + 1.3) }}>Non boutik ou</div>
    <div style={{ ...abs(32, 940, W - 64, 96), borderRadius: 999, border: `3px solid ${C.ink}`, boxSizing: 'border-box', display: 'flex', alignItems: 'center', padding: '0 32px', font: `400 36px ${FH}`, color: C.ink, opacity: MOTION.enter(T, b + 1.3) }}>{typed(S.store, T, b + 1.5, 0.9)}</div>
    <Btn y={1110} dark label="Kontinye" />
    <Tap T={T} x={sp.x + 131} y={sp.y + 29} at={b + 0.9} />
    <Tap T={T} x={302} y={1160} at={b + 3.0} />
  </Screen>;
}

function Products({ T, S, c }) {
  const P = c.Products;
  const fills = [C.tint, C.ink, C.green];
  const inks = [C.greenDeep, C.green, C.ink];
  const count = [0, 1, 2].filter((k) => T > P + 0.35 + k).length;
  return <Screen T={T} from={P} to={c.Plan}>
    <StatusBar />
    <Title sub={`${count} / 3 ${S.itemsWord}`}>{S.itemsTitle}</Title>
    {S.items.map(([n, pr], k) => {
      const p = MOTION.pop(T, P + 0.35 + k, 0.5);
      return <div key={k} style={{ ...abs(32, 270 + k * 236, W - 64, 212), borderRadius: 40, background: C.white, boxShadow: '0 10px 30px rgba(0,0,0,0.08)', display: 'flex', alignItems: 'center', gap: 24, padding: 22, boxSizing: 'border-box', opacity: Math.min(1, p), transform: `translateY(${(1 - p) * 40}px) scale(${0.9 + 0.1 * p})` }}>
        <div style={{ width: 168, height: 168, flex: 'none', borderRadius: 32, background: fills[k], display: 'flex', alignItems: 'center', justifyContent: 'center', font: `400 80px ${FH}`, color: inks[k], position: 'relative', overflow: 'hidden' }}>{n[0]}<image-slot id={`ad-${S.slug}-item-${k}`} shape="rect" placeholder="Foto" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}></image-slot></div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div style={{ font: `700 30px/1.2 ${FB}`, color: C.ink }}>{n}</div>
          <div style={{ font: `400 36px ${FH}`, color: C.greenDeep }}>{pr}</div>
        </div>
      </div>;
    })}
    <Btn y={1110} dark label={`+ Ajoute ${S.itemsWord}`} />
    {[0, 1, 2].map((k) => <Tap key={k} T={T} x={302} y={1160} at={P + 0.2 + k} />)}
  </Screen>;
}

const PLANS = [['Gratis', '$0', '10 pwodwi · kòmand WhatsApp'], ['Pro', '$9', 'San limit · Gaya Pay · 5 lang'], ['Biznis', '$25', 'Plizyè boutik · ekip · rapò']];
const METHODS = ['MonCash', 'NatCash', 'Kat Visa / Mastercard', 'PayPal', 'Apple Pay / Google Pay'];

function Plan({ T, c }) {
  const L = c.Plan;
  const pro = T > L + 1.35;
  const sheet = MOTION.enter(T, L + 2.2, 0.5);
  const mSel = T > L + 2.85;
  const spin = T > L + 3.6 && T < L + 4.45;
  const done = MOTION.pop(T, L + 4.45, 0.55);
  const doneO = MOTION.enter(T, L + 4.4, 0.3);
  const ST = 454;
  return <Screen T={T} from={L} to={c.Launch}>
    <StatusBar />
    <Title sub="Chanje oswa anile nenpòt ki lè">Chwazi plan ou</Title>
    {PLANS.map(([n, pr, d], k) => {
      const on = pro && k === 1;
      return <div key={n} style={{ ...abs(32, 290 + k * 250, W - 64, 224), borderRadius: 40, background: k === 1 ? C.ink : '#F1F4F2', color: k === 1 ? C.white : C.ink, border: `5px solid ${on ? C.green : 'transparent'}`, boxSizing: 'border-box', padding: '30px 34px', display: 'flex', flexDirection: 'column', gap: 10, opacity: MOTION.enter(T, L + 0.15 + k * 0.15) }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ font: `800 32px ${FB}` }}>{n}</span>
          {k === 1 && <span style={{ background: C.green, color: C.ink, borderRadius: 999, padding: '6px 18px', font: `800 20px ${FB}` }}>PI POPILÈ</span>}
        </div>
        <div style={{ font: `400 56px ${FH}` }}>{pr}<span style={{ font: `600 24px ${FB}` }}> / mwa</span></div>
        <div style={{ font: `500 24px ${FB}`, opacity: 0.8 }}>{d}</div>
      </div>;
    })}
    <Btn y={1100} green label="Kontinye ak Pro" />
    <div style={{ ...abs(0, 0, W, H), background: 'rgba(11,11,11,0.5)', opacity: sheet, zIndex: 10 }}></div>
    <div style={{ ...abs(0, ST, W, 820), background: C.white, borderRadius: '48px 48px 0 0', transform: `translateY(${(1 - sheet) * 840}px)`, zIndex: 11 }}>
      <div style={{ ...abs(32, 40, W - 64, 'auto'), font: `400 42px ${FH}`, color: C.ink }}>Peye abònman an</div>
      <div style={{ ...abs(32, 104, W - 64, 'auto'), font: `600 24px ${FB}`, color: C.grey }}>Plan Pro · $9 / mwa</div>
      {METHODS.map((m, k) => {
        const on = mSel && k === 0;
        return <div key={m} style={{ ...abs(32, 170 + k * 96, W - 64, 82), borderRadius: 999, background: on ? C.tint : '#F5F7F6', border: `3px solid ${on ? C.greenDeep : 'transparent'}`, boxSizing: 'border-box', display: 'flex', alignItems: 'center', gap: 18, padding: '0 28px', font: `700 27px ${FB}`, color: C.ink }}>
          <span style={{ width: 30, height: 30, borderRadius: 999, border: `3px solid ${on ? C.greenDeep : '#B7BEB9'}`, boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{on && <span style={{ width: 14, height: 14, borderRadius: 999, background: C.greenDeep }}></span>}</span>{m}
        </div>;
      })}
      <div style={{ ...abs(32, 670, W - 64, 100), borderRadius: 999, background: C.ink, color: C.white, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `700 32px ${FB}` }}>
        {spin ? <span style={{ width: 44, height: 44, borderRadius: 999, border: '5px solid rgba(255,255,255,0.25)', borderTopColor: C.green, boxSizing: 'border-box', transform: `rotate(${T * 720}deg)` }}></span> : 'Peye $9 ak MonCash'}
      </div>
    </div>
    <div style={{ ...abs(0, 0, W, H), background: C.green, opacity: doneO, zIndex: 20, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 28 }}>
      <div style={{ width: 200, height: 200, borderRadius: 999, background: C.ink, color: C.green, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `800 110px ${FB}`, transform: `scale(${done})` }}>✓</div>
      <div style={{ font: `400 60px ${FH}`, color: C.ink }}>Peman reyisi!</div>
      <div style={{ font: `600 30px ${FB}`, color: C.ink }}>Plan Pro aktive · $9 / mwa</div>
      <div style={{ font: `500 24px ${FB}`, color: C.ink }}>Resi a voye sou WhatsApp ou</div>
    </div>
    <Tap T={T} x={302} y={540 + 112} at={L + 1.3} />
    <Tap T={T} x={302} y={1150} at={L + 1.9} />
    <Tap T={T} x={200} y={ST + 170 + 41} at={L + 2.8} />
    <Tap T={T} x={302} y={ST + 720} at={L + 3.5} />
  </Screen>;
}

function Launch({ T, S, c }) {
  const N = c.Launch;
  const card = MOTION.pop(T, N + 1.2, 0.55);
  const burst = MOTION.enter(T, N + 1.05, 1.1);
  return <Screen T={T} from={N} to={c.Order}>
    <div style={{ ...abs(0, 0, W, 420), background: C.green }}></div>
    <div style={{ ...abs(W - 250, 96, 218, 218), borderRadius: 999, overflow: 'hidden', background: '#00BD55', border: `6px solid ${C.white}`, boxSizing: 'border-box' }}><image-slot id={`ad-${S.slug}-owner`} shape="circle" placeholder="Foto pwopriyetè a" style={{ width: '100%', height: '100%' }}></image-slot></div>
    <StatusBar />
    <div style={{ ...abs(32, 120, W - 300, 'auto'), display: 'flex', flexDirection: 'column', gap: 18 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, font: `800 22px ${FB}`, color: C.ink }}><span style={{ width: 16, height: 16, borderRadius: 999, background: C.ink }}></span>AN LIY</div>
      <div style={{ font: `400 64px/1.05 ${FH}`, color: C.ink }}>{S.store}</div>
      <div style={{ alignSelf: 'flex-start', background: C.white, borderRadius: 999, padding: '10px 22px', font: `700 24px ${FB}`, color: C.ink }}>gayamaket.com/{S.slug}</div>
    </div>
    {S.items.map(([n, pr], k) => <div key={k} style={{ ...abs(32, 460 + k * 124, W - 64, 104), display: 'flex', alignItems: 'center', gap: 20 }}>
      <div style={{ width: 96, height: 96, borderRadius: 24, background: [C.tint, C.ink, C.green][k], color: [C.greenDeep, C.green, C.ink][k], display: 'flex', alignItems: 'center', justifyContent: 'center', font: `400 44px ${FH}` }}>{n[0]}</div>
      <div style={{ flex: 1, font: `700 27px ${FB}`, color: C.ink }}>{n}</div>
      <div style={{ font: `400 28px ${FH}`, color: C.greenDeep }}>{pr}</div>
    </div>)}
    <div style={{ ...abs(32, 860, W - 64, 60), display: 'flex', gap: 10 }}>
      {['Kreyòl', 'EN', 'ES', 'FR', 'PT'].map((l, k) => <span key={l} style={{ borderRadius: 999, padding: '10px 18px', background: k === 0 ? C.ink : '#F1F4F2', color: k === 0 ? C.white : C.ink, font: `700 22px ${FB}` }}>{l}</span>)}
    </div>
    <Btn y={1110} dark label="Pataje sou WhatsApp" />
    {Array.from({ length: 16 }).map((_, i) => {
      const ang = (i / 16) * Math.PI * 2 + 0.3; const d = 120 + (i % 3) * 70;
      return <div key={i} style={{ position: 'absolute', left: 302 + Math.cos(ang) * d * burst - 10, top: 1160 + Math.sin(ang) * d * burst * 0.9 - 10 - burst * 120, width: i % 2 ? 20 : 28, height: i % 2 ? 20 : 28, borderRadius: 999, background: i % 3 === 0 ? C.ink : C.green, opacity: T > N + 1.05 ? 1 - burst : 0, zIndex: 30 }}></div>;
    })}
    <div style={{ ...abs(48, 380, W - 96, 380), borderRadius: 44, background: C.white, boxShadow: '0 30px 80px rgba(0,0,0,0.22)', opacity: Math.min(1, card), transform: `scale(${0.7 + 0.3 * card})`, zIndex: 31, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22, textAlign: 'center' }}>
      <div style={{ font: `400 46px ${FH}`, color: C.ink }}>Boutik ou an liy!</div>
      <div style={{ background: C.green, borderRadius: 999, padding: '14px 26px', font: `800 26px ${FB}`, color: C.ink }}>gayamaket.com/{S.slug}</div>
      <div style={{ font: `600 24px ${FB}`, color: C.grey }}>Status · Gwoup · Chat</div>
    </div>
    <Tap T={T} x={302} y={1160} at={N + 1.0} />
  </Screen>;
}

function Order({ T, S, c }) {
  const O = c.Order;
  const m1 = MOTION.pop(T, O + 0.3, 0.45), card = MOTION.pop(T, O + 1.0, 0.55), note = MOTION.enter(T, O + 2.3, 0.5), rep = MOTION.pop(T, O + 3.3, 0.45);
  return <Screen T={T} from={O} to={c.CTA + 0.6} bg={C.chat}>
    <div style={{ ...abs(0, 0, W, 160), background: C.ink }}></div>
    <StatusBar light />
    <div style={{ ...abs(32, 64, W - 64, 80), display: 'flex', alignItems: 'center', gap: 18 }}>
      <div style={{ width: 72, height: 72, borderRadius: 999, background: C.green, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `400 34px ${FH}`, color: C.ink }}>{S.store[0]}</div>
      <div><div style={{ font: `700 30px ${FB}`, color: C.white }}>{S.store}</div><div style={{ font: `500 22px ${FB}`, color: '#BFC6C1' }}>Kòmand otomatik</div></div>
    </div>
    <div style={{ ...abs(24, 196, 470, 'auto'), background: C.white, borderRadius: '10px 30px 30px 30px', padding: '20px 26px', font: `500 28px/1.3 ${FB}`, color: C.ink, opacity: Math.min(1, m1), transform: `scale(${0.92 + 0.08 * m1})`, transformOrigin: 'left top' }}>Bonjou! M fèk pase kòmand lan.</div>
    <div style={{ ...abs(24, 330, W - 90, 'auto'), background: C.white, borderRadius: '10px 36px 36px 36px', padding: 30, boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: 18, opacity: Math.min(1, card), transform: `translateY(${(1 - card) * 30}px) scale(${0.92 + 0.08 * card})`, transformOrigin: 'left top' }}>
      <div style={{ alignSelf: 'flex-start', background: C.ink, color: C.green, borderRadius: 999, padding: '8px 20px', font: `800 22px ${FB}` }}>{S.orderWord} #1042</div>
      {S.order.map(([n, p], k) => <div key={k} style={{ display: 'flex', justifyContent: 'space-between', gap: 16, font: `600 26px ${FB}`, color: C.ink }}><span>{n}</span><span>{p}</span></div>)}
      <div style={{ height: 3, borderRadius: 999, background: C.line }}></div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', color: C.ink }}><span style={{ font: `700 26px ${FB}` }}>Total</span><span style={{ font: `400 40px ${FH}` }}>{S.total} HTG</span></div>
      <div style={{ font: `500 22px ${FB}`, color: C.grey }}>{S.detail}</div>
      <div style={{ alignSelf: 'flex-start', display: 'flex', alignItems: 'center', gap: 10, background: C.green, borderRadius: 999, padding: '10px 22px', font: `800 24px ${FB}`, color: C.ink }}>✓ Peye ak MonCash</div>
    </div>
    <div style={{ ...abs(150, 800, W - 174, 'auto'), background: C.tint, borderRadius: '30px 10px 30px 30px', padding: '20px 26px', boxSizing: 'border-box', font: `600 28px/1.3 ${FB}`, color: C.ink, opacity: Math.min(1, rep), transform: `scale(${0.92 + 0.08 * rep})`, transformOrigin: 'right top' }}>{typed(S.reply, T, O + 3.35, 0.9)}</div>
    <div style={{ ...abs(20, 20, W - 40, 120), borderRadius: 36, background: C.white, boxShadow: '0 20px 50px rgba(0,0,0,0.25)', display: 'flex', alignItems: 'center', gap: 18, padding: '0 24px', boxSizing: 'border-box', transform: `translateY(${(1 - note) * -170}px)`, zIndex: 40 }}>
      <div style={{ width: 72, height: 72, borderRadius: 999, background: C.ink, color: C.green, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `400 40px ${FH}` }}>G</div>
      <div style={{ flex: 1 }}><div style={{ font: `800 24px ${FB}`, color: C.ink }}>Gaya Pay</div><div style={{ font: `600 24px ${FB}`, color: C.grey }}>Ou resevwa yon peman</div></div>
      <div style={{ font: `400 34px ${FH}`, color: C.greenDeep }}>+{S.total}</div>
    </div>
  </Screen>;
}

const COPY = {
  ht: { heads: (S) => ['Ou toujou ap vann nan chat?', 'Gen yon pi bon fason.', 'Kreye kont ou an 1 minit', `Mete ${S.itemsWord} ou yo`, 'Peye abònman ou fasil', 'Lanse boutik ou', 'Kòmand ak lajan antre poukont yo'], step: 'ETAP',
    cta1: (S) => `Mete ${S.ctaFor} ou sou WhatsApp.`, cta2: 'Kòmanse jodi a.',
    vo: (S) => ['Ou toujou ap reponn menm kesyon yo nan WhatsApp tout lajounen?', 'Men Gaya Maket. Boutik ou, dirèkteman sou WhatsApp.', 'Premye etap: antre nimewo WhatsApp ou, mete kòd la, chwazi kalite biznis ou epi bay boutik ou yon non.', `Dezyèm etap: pran yon foto, mete pri a, epi ${S.itemsWord} ou yo pare pou vann.`, 'Twazyèm etap: chwazi plan ou epi peye abònman an ak MonCash, NatCash oswa kat ou. Sa pran kèk segonn.', 'Katriyèm etap: pataje lyen boutik ou sou Status, nan gwoup ak nan chat.', 'Kliyan yo pase kòmand epi peye poukont yo. Lajan an antre nan Gaya Pay touswit.', 'Gaya Maket. Kòmanse jodi a sou gayamaket.com.'] },
  es: { heads: () => ['¿Sigues vendiendo por chat?', 'Hay una mejor manera.', 'Crea tu cuenta en 1 minuto', 'Agrega tus productos', 'Paga tu suscripción fácil', 'Lanza tu tienda', 'Pedidos y pagos llegan solos'], step: 'PASO',
    cta1: () => 'Pon tu negocio en WhatsApp.', cta2: 'Empieza hoy.',
    vo: () => ['¿Sigues respondiendo las mismas preguntas por WhatsApp todo el día?', 'Te presentamos Gaya Maket. Tu tienda, directo en WhatsApp.', 'Paso uno: ingresa tu número de WhatsApp, confirma el código, elige tu tipo de negocio y ponle nombre a tu tienda.', 'Paso dos: toma una foto, pon el precio y tus productos quedan listos para vender.', 'Paso tres: elige tu plan y paga la suscripción con MonCash, NatCash o tu tarjeta. En segundos.', 'Paso cuatro: comparte el enlace de tu tienda en tus estados, grupos y chats.', 'Tus clientes piden y pagan solos. El dinero llega al instante a Gaya Pay.', 'Gaya Maket. Empieza hoy en gayamaket.com.'] },
};
const SCENE_KEYS = ['Hook', 'Reveal', 'Account', 'Products', 'Plan', 'Launch', 'Order', 'CTA'];
const HEADS = (S, L) => { const h = COPY[L].heads(S), st = COPY[L].step; return [
  { s: -1, e: 'Reveal', k: null, t: h[0] },
  { s: 'Reveal', e: 'Account', k: null, t: h[1] },
  { s: 'Account', e: 'Products', k: st + ' 1', t: h[2] },
  { s: 'Products', e: 'Plan', k: st + ' 2', t: h[3] },
  { s: 'Plan', e: 'Launch', k: st + ' 3', t: h[4] },
  { s: 'Launch', e: 'Order', k: st + ' 4', t: h[5] },
  { s: 'Order', e: 'CTA', k: null, t: h[6] },
]; };

function Headline({ T, S, c, L }) {
  return <React.Fragment>{HEADS(S, L).map((h, i) => {
    const s = typeof h.s === 'string' ? c[h.s] : h.s, e = c[h.e];
    const o = span(T, s, e, 0.3);
    const y = (1 - MOTION.enter(T, s, 0.5)) * 30 - MOTION.enter(T, e, 0.3) * 20;
    return <div key={i} style={{ ...abs(80, 120, 920, 360), display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22, textAlign: 'center', opacity: o, visibility: o < 0.002 ? 'hidden' : 'visible', transform: `translateY(${y}px)` }}>
      {h.k && <span style={{ background: C.green, color: C.ink, borderRadius: 999, padding: '10px 26px', font: `800 30px ${FB}`, letterSpacing: '0.06em' }}>{h.k}</span>}
      <div style={{ font: `400 80px/1.08 ${FH}`, color: C.ink, textWrap: 'balance' }}>{h.t}</div>
    </div>;
  })}</React.Fragment>;
}

function CTA({ T, S, c, L }) {
  const Z = c.CTA;
  const a = MOTION.pop(T, Z + 0.35, 0.6), b = MOTION.enter(T, Z + 0.7, 0.5), d = MOTION.pop(T, Z + 1.1, 0.5), e = MOTION.enter(T, Z + 1.5, 0.5);
  const o = MOTION.enter(T, Z + 0.2, 0.4);
  return <div style={{ ...abs(0, 0, 1080, 1920), display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 46, opacity: o, visibility: o < 0.002 ? 'hidden' : 'visible', textAlign: 'center' }}>
    <div style={{ width: 280, height: 280, borderRadius: 999, background: C.ink, color: C.green, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `400 190px ${FH}`, transform: `scale(${a})` }}>G</div>
    <div style={{ font: `400 132px ${FH}`, color: C.ink, opacity: b, transform: `translateY(${(1 - b) * 30}px)` }}>Gaya Maket</div>
    <div style={{ font: `600 44px/1.3 ${FB}`, color: C.ink, opacity: b, maxWidth: 820 }}>{COPY[L].cta1(S)}<br />{COPY[L].cta2}</div>
    <div style={{ background: C.ink, color: C.green, borderRadius: 999, padding: '28px 64px', font: `800 50px ${FB}`, transform: `scale(${d})` }}>gayamaket.com</div>
    <div style={{ display: 'flex', gap: 14, opacity: e }}>
      {['Kreyòl', 'English', 'Español', 'Français', 'Português'].map((l) => <span key={l} style={{ background: C.white, border: `3px solid ${C.ink}`, borderRadius: 999, padding: '10px 22px', font: `700 28px ${FB}`, color: C.ink }}>{l}</span>)}
    </div>
  </div>;
}

function Piece({ S, L, subs }) {
  const { T, CUES: c } = useComposition();
  const out = MOTION.enter(T, c.CTA, 0.8);
  const drift = Math.sin(T * 0.5);
  const zoom = 1 + 0.025 * Math.sin(T * 0.4);
  return <div data-screen-label={`t=${Math.floor(T)}s`} style={{ position: 'absolute', inset: 0, background: C.white, overflow: 'hidden', fontFamily: FB }}>
    <div style={{ position: 'absolute', left: -380 + drift * 30, top: 1180 - drift * 20 - out * 300, width: 1100, height: 1100, borderRadius: 999, background: C.green, transform: `scale(${1 + out * 0.4})` }}></div>
    <div style={{ position: 'absolute', right: -230 - drift * 20, top: 1420 + drift * 15 + out * 400, width: 560, height: 560, borderRadius: 999, background: C.ink }}></div>
    <div style={{ position: 'absolute', left: -90 + drift * 10, top: -70, width: 300, height: 300, borderRadius: 999, background: C.tint }}></div>
    <Headline T={T} S={S} c={c} L={L} />
    <div style={{ position: 'absolute', left: 220, top: 520, width: 640, height: 1290, borderRadius: 92, background: C.ink, boxShadow: '0 40px 100px rgba(0,0,0,0.28)', transform: `translateY(${out * 1500}px) scale(${zoom})`, transformOrigin: '50% 30%' }}>
      <div style={{ position: 'absolute', left: 18, top: 18, width: W, height: H, borderRadius: 76, overflow: 'hidden', background: C.white }}>
        <HookChat T={T} S={S} c={c} />
        <Brand T={T} c={c} />
        <Signup T={T} c={c} />
        <BizType T={T} S={S} c={c} />
        <Products T={T} S={S} c={c} />
        <Plan T={T} c={c} />
        <Launch T={T} S={S} c={c} />
        <Order T={T} S={S} c={c} />
      </div>
      <div style={{ position: 'absolute', left: 250, top: 34, width: 140, height: 36, borderRadius: 999, background: C.ink, zIndex: 60 }}></div>
    </div>
    <CTA T={T} S={S} c={c} L={L} />
    {subs && <Captions items={COPY[L].vo(S).map((text, i) => ({ at: c[SCENE_KEYS[i]] + 0.2, until: (i + 1 < SCENE_KEYS.length ? c[SCENE_KEYS[i + 1]] : c.CTA + 4) - 0.1, text }))} style={{ left: 60, right: 60, bottom: 36, background: 'rgba(11,11,11,0.9)', borderRadius: 40, padding: '22px 34px', font: `600 34px/1.35 ${FB}`, color: '#FFFFFF', textShadow: 'none' }} />}
  </div>;
}

function GayaAd() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  const S = SERVICES.find((s) => s.type === t.service) || SERVICES[0];
  return <React.Fragment>
    <CompositionStage width={1080} height={1920} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#FFFFFF">
      <Piece S={S} L={t.adLang === 'Español' ? 'es' : 'ht'} subs={t.subtitles !== false} />
    </CompositionStage>
    <TweaksPanel title="Tweaks">
      <TweakSection label="Piblisite" />
      <TweakSelect label="Sèvis" value={t.service} options={SERVICES.map((s) => s.type)} onChange={(v) => setTweak('service', v)} />
      <TweakRadio label="Lang" value={t.adLang || 'Kreyòl'} options={['Kreyòl', 'Español']} onChange={(v) => setTweak('adLang', v)} />
      <TweakToggle label="Sou-tit / vwa" value={t.subtitles !== false} onChange={(v) => setTweak('subtitles', v)} />
      <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
    </TweaksPanel>
  </React.Fragment>;
}

window.GayaAd = GayaAd;
